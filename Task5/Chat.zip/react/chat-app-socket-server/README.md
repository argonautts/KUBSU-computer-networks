# chat-app-socket-server

This is a socket-server project needs front end application to operate this.
front end application repository name react-chat-app-front-end
