// jest-dom добавляет пользовательские сопоставители jest для утверждения на узлах DOM.
// позволяет делать такие вещи, как:
// ожидаем (элемент) .toHaveTextContent (/react /i)
import '@testing-library/jest-dom';
